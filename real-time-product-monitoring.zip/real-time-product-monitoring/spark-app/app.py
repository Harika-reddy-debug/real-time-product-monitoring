from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StringType, IntegerType

# Start Spark session
spark = SparkSession.builder \
    .appName("KafkaToClickHouse") \
    .getOrCreate()

spark.sparkContext.setLogLevel("WARN")

# Define Kafka topic and schema
kafka_topic = "customer-events"

schema = StructType() \
    .add("user_id", IntegerType()) \
    .add("product", StringType()) \
    .add("action", StringType()) \
    .add("timestamp", StringType())

# Read stream from Kafka
df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "kafka:9092") \
    .option("subscribe", kafka_topic) \
    .load()

# Convert Kafka value to JSON
json_df = df.selectExpr("CAST(value AS STRING)") \
    .select(from_json(col("value"), schema).alias("data")) \
    .select("data.*")

# Write to console (for testing)
query = json_df.writeStream \
    .format("console") \
    .outputMode("append") \
    .start()

query.awaitTermination()
